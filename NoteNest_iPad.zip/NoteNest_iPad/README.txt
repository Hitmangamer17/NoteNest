# NoteNest — iPad note-taking starter app

NoteNest is an original, offline-first browser note app prototype designed for iPad.

## Included
- Create and organize notes by subject
- Search note titles and content
- Typed notes with bold, italic, underline, and lists
- Apple Pencil/finger drawing canvas with several ink colors, adjustable width, and eraser mode
- Star important notes
- Local autosave in the browser
- Export a note as text
- Export/import a JSON backup of your notes

## Important limitations
This is a useful starter app, not a full Notability replacement. It does not yet include full PDF import/annotation, audio recording/transcription, handwriting recognition, iCloud sync, or App Store packaging. Drawing is stored as strokes in the local browser app. Keep backups using Export.

## Try it
1. Open `index.html` in a modern browser.
2. On iPad, transfer `index.html` to the iPad and open it from Files, or host this folder on an HTTPS static site for a more reliable Home Screen web-app experience.
3. For an installed Home Screen web app, open the hosted page in Safari, tap Share → Add to Home Screen, enable “Open as Web App” if shown, then tap Add.

A local HTML file may not behave exactly like a hosted web app on every iPadOS version. To publish it as a Home Screen web app, the files need to be hosted at a web address. A native App Store app would require an Xcode build and signing.
